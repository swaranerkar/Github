package com.google.firebase.codelab.friendlychat;

public class IpAddress {
    public String getCip() {
        return cip;
    }

    public void setCip(String cip) {
        this.cip = cip;
    }

    String cip;

}
